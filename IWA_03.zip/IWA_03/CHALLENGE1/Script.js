

const message = '© ' + company + ' (' + year + ')'
document.querySelector('footer').innerText = message