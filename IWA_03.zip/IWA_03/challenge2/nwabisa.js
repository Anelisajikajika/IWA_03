/*private firstname = "nwabisa"
private surname = "Gabe"
public role = "CEO" 

private display= firstname + " " + surname + " (" + role + ")"
document.querySelector('#nwabisa').innerText = display*/