/*private firstname = "Alex"
private surname = "Naidoo"
public role = "Head of Marketing"

private display= firstname + " " + surname + " (" + role + ")"
document.querySelector('#alex').innerText = displa*/